# BXGu
Android final homework for 2019Q2.

Now the project is available on both Github(fhh200000/BXGu)and Tencent git(NoException/BXGu).
